public interface IFuncoesVeiculos {
    void abastecer();
    void acelerar(int velocidade);
}
