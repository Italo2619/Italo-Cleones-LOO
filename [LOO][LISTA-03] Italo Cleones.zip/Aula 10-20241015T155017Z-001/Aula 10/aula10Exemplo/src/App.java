public class App {
    public static void main(String[] args) {
        SistemaEscola sistemaEscola = new SistemaEscola();
        sistemaEscola.executar();
    }
}