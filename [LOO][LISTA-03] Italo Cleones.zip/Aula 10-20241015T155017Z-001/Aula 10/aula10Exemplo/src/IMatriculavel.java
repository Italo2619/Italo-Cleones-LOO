public interface IMatriculavel {
    void matricular(String rga);
    void cancelarMatricula();
}